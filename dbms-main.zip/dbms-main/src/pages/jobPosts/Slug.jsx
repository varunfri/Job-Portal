import React from "react";

const slug = () => {
  return <div>slug</div>;
};

export default slug;
