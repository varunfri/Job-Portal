import About from "./About";
import Home from "./Home";
import Error from "./Error";

export { About, Home, Error };
