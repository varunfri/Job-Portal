import React from "react";

const Error = () => {
  return <div>ERROR</div>;
};

export default Error;
